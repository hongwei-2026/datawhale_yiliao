# 病例导入 · 三种模式演示包（录视频用）

本目录三套样例一一对应管理端「添加病例」三个入口。云端路径相同：`web/data/samples/`。

| 模式 | 文件 | 建议选项 | 演示重点 |
|------|------|----------|----------|
| **写个大概** | [`sample-rough-liudashan-htn-followup.txt`](./sample-rough-liudashan-htn-followup.txt) | 场景：随访 · 病种：高血压 · 称呼：刘大山 | 短文 →「扩写成案例文稿」→ 再整理成卡片 |
| **交材料** | [`sample-material-zhouminghua-icf-with-junk.zip`](./sample-material-zhouminghua-icf-with-junk.zip) | 场景：知情同意 · 病种：2型糖尿病 · 称呼：周明华 | 上传 ZIP → 文件审核（保留/刷掉垃圾）→ 整理卡片 |
| **纯人写** | [`sample-human-chenmeiling-followup.txt`](./sample-human-chenmeiling-followup.txt) | 场景：随访 · 病种：2型糖尿病 · 称呼：陈美玲 | 粘贴全文 →「整理成练习卡片」→ 审核发布（系统不编造事实） |

## 录视频建议顺序（约 6～8 分钟）

1. **交材料（最直观）**  
   管理端 → 添加病例 → 交材料 → 选知情同意 + 糖尿病 → 拖入 ZIP → 展示「建议保留 / 刷掉」→ 确认 → 整理 → 勾选核对 → 发布。

2. **写个大概（看 AI 扩写）**  
   写个大概 → 随访 + 高血压 → 粘贴刘大山短文 → 扩写成案例文稿 → 改两句 → 整理成卡片 → 发布。

3. **纯人写（强调人审）**  
   纯人写 → 随访 + 糖尿病 → 粘贴陈美玲全文 → 整理成卡片 → 对照左边原文 → 发布。

发布后学员端选人页应按 **知情同意 / 随访** 分组显示；病种挂在卡片说明里。

## 重新生成交材料 ZIP

```bash
python scripts/gen_sample_material_zip.py
```

## 一键打包（本机发给自己用）

```bash
python scripts/gen_demo_ingest_packs.py
```

会在本目录生成 `AISP-三路径导入演示包.zip`（含上述三个文件 + 本说明）。
